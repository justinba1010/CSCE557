#! /usr/local/bin/python3
import string
import sys
from random import randint, choice

kNumberOfRuns = 15000
kTotalRuns = 250000
kSwapSpace = 1  # Increase after certain number
kKeep = 10
kAlphabetWeight = 0

# The search space is 36!, so we're going to do a greedy algorithm to find
# a reasonable sub search space. First we're going to do 1:1 frequency, then
# like a genetic algorithm, we'll make a random 2-swap, if we get closer, we
# will build upon it, if not we start anew. We will keep all substitutions 
# that are within a reasonable distance to english text.

def heuristic(englishWordRate, alphabetRate):
    # I was trying to solve others
    # and realized I perhaps need to add some
    # better search function
    # for now it is a simple heuristic
    return (englishWordRate + kAlphabetWeight*alphabetRate)

def twoSwap(frequency):
    index = randint(0, len(frequency) - 1)
    nextIndex = max(0, index + randint(0, kSwapSpace)) % (len(frequency))
    frequency[index], frequency[nextIndex] = frequency[nextIndex], frequency[index]

def substitute(word, originalFrequency, changeFrequency):
    return "".join([originalFrequency[changeFrequency.index(letter)] for letter in word])

def printSub(hitRate, alphabetRate, frequency, frequencyCipherText):
    print("The substitution below has a {}% English word rate and a {}% alphabet rate".format(hitRate*100, alphabetRate*100))
    print("|" + "|".join(frequency))
    print("|" + "|".join(frequencyCipherText))

def trySub(wordsIn, frequency, frequencyCipherText, tenkwords, frequencyOfCipherText):
    count = 0
    alphabetic = 0
    for word in wordsIn:
        # print("word: " + word)
        newWord = substitute(word, frequency, frequencyCipherText)
        # print(newWord)
        if all([not letter in "0123456789" for letter in newWord]):
            alphabetic += 1
        if newWord in tenkwords:
            count += 1
    hitRate = count/len(wordsIn)
    return (hitRate, alphabetic/len(wordsIn))

def main():
    alphabet = list(string.ascii_lowercase + string.digits)
    tenkwords = set(open("10kwords.txt").read().splitlines())

    # english frequency in order
    frequency = list("etaoinsrhdlucmfywgpbvkxqjz1234567890")

    if len(sys.argv) < 2:
        print("Please enter a filename after, ./decipher.py filename.txt")
        exit(SystemExit(1))

    filename = sys.argv[1]
    wordsIn = open(filename).read().split()
    letters = [letter for word in wordsIn for letter in word]

    # Get frequency of cipherText
    frequencyOfCipherText = {}
    for letter in alphabet:
        frequencyOfCipherText[letter] = 0
    for letter in letters:
        frequencyOfCipherText[letter] += 1

    # Make first matching
    frequencyCipherText = ""
    while len(frequencyOfCipherText) > 0:
        (key, _value) = max(frequencyOfCipherText.items(), key = lambda k : k[1])
        frequencyCipherText += key
        del frequencyOfCipherText[key]
    frequencyCipherText = list(frequencyCipherText)

    print(frequency)
    print(frequencyCipherText)
    bestLists = []
    k = 0
    i = 0
    bestRate = -1
    global kSwapSpace
    while k < kTotalRuns:
        if i == kNumberOfRuns:
            print("Increasing swap space")
            if kSwapSpace >= len(alphabet)-3:
                print("We've exhausted all reasonable swap distances, try changing heuristics")
                break
            i = 0
            kSwapSpace += 1
        (hitRate, alphabetic) = trySub(wordsIn, frequency, frequencyCipherText, tenkwords, frequencyOfCipherText)
        x = (hitRate, "".join(frequencyCipherText), k, alphabetic)
        bestLists.append(x)
        bestLists = sorted(bestLists, key=lambda x: heuristic(x[0], x[3]), reverse=True)[:kKeep]
        rate = heuristic(hitRate, alphabetic)
        if rate > bestRate:
            i = 0
            k = 0
            bestRate = rate
            printSub(hitRate, rate, frequency, frequencyCipherText)
        (_, newFrequencyCipherText, _, alphabeticRate) = choice(bestLists)
        frequencyCipherText = list(newFrequencyCipherText)
        twoSwap(frequencyCipherText)
        k += 1
        i += 1
    for i in range(kKeep):
        filey = open("key" + str(i) + ".txt", "w+")
        filey.write("".join(bestLists[i][1]))
        filey.close()

if __name__ == "__main__":
    main()
