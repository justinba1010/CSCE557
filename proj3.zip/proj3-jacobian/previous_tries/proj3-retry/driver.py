"""
Justin Baum
20 October 2020
driver.py
Driver code for using the Elliptic Curve
"""

